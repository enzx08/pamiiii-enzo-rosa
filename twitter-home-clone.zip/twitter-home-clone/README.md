# Twitter Home Clone

A React Native Expo app built with Expo Router and TypeScript that recreates the Twitter/X mobile home timeline.

## Run locally

1. Install dependencies:
   ```bash
   cd twitter-home-clone
   npm install
   ```
2. Start the app:
   ```bash
   npx expo start
   ```

The app includes a home header, tweet composer, a sample tweet card, and a bottom navigation bar.
