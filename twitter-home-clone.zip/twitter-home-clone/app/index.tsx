import React from "react"; // Adicionado para garantir compatibilidade
import { StatusBar } from "expo-status-bar";
import { ScrollView, StyleSheet, View, SafeAreaView } from "react-native";
import Header from "../components/Header";
import TweetCard from "../components/TweetCard";
import TweetComposer from "../components/TweetComposer";
import BottomNav from "../components/BottomNav";

// Definição da interface para garantir que os dados batam com o TweetCard
interface Tweet {
  id: string;
  author: {
    name: string;
    handle: string;
    avatar: string;
  };
  time: string;
  content: string;
  image?: string;
  stats: {
    replies: number;
    reposts: number;
    likes: number;
    views: string;
  };
}

const tweets: Tweet[] = [
  {
    id: "1",
    author: {
      name: "Elon Musk",
      handle: "@elonmusk",
      avatar: "https://pbs.twimg.com/profile_images/1594633197892851968/HpHJI9F2_400x400.jpg"
    },
    time: "2h",
    content: "Starship will change humanity forever.",
    image: "https://images.unsplash.com/photo-1519125323398-675f0ddb6308?auto=format&fit=crop&w=900&q=80",
    stats: {
      replies: 15,
      reposts: 104,
      likes: 1240,
      views: "67K"
    }
  }
];

export default function HomeScreen() {
  return (
    // O SafeAreaView deve envolver o conteúdo para evitar que o Header suba para a barra de status
    <SafeAreaView style={styles.safeArea}>
      <StatusBar style="dark" />
      
      <View style={styles.container}>
        <Header />
        
        <ScrollView
          style={styles.feed}
          contentContainerStyle={styles.feedContent}
          showsVerticalScrollIndicator={false}
        >
          <TweetComposer />
          <View style={styles.divider} />
          
          {tweets.map((tweet) => (
            // Passamos o objeto tweet conforme a interface esperada pelo TweetCard
            <TweetCard key={tweet.id} tweet={tweet} />
          ))}
        </ScrollView>
      </View>

      {/* A navegação inferior fica fixa fora do ScrollView */}
      <BottomNav />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: "#ffffff"
  },
  container: {
    flex: 1,
  },
  feed: {
    flex: 1,
  },
  feedContent: {
    // Espaçamento reduzido para não sobrar um "buraco" no final da lista
    paddingBottom: 20 
  },
  divider: {
    height: 8,
    backgroundColor: "#f7f9f9", // Cor cinza bem clara padrão do Twitter/X
    borderTopWidth: StyleSheet.hairlineWidth,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderColor: "#eff3f4"
  }
});