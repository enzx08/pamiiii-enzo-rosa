import { Stack } from "expo-router";

// Layout raiz para as rotas do Expo Router.
export default function Layout() {
  return (
    <Stack
      screenOptions={{
        // Desativa o cabeçalho padrão para usarmos o nosso Header personalizado
        headerShown: false,
        // Garante uma transição suave entre telas
        animation: "fade",
        contentStyle: { backgroundColor: "#ffffff" }
      }}
    />
  );
}